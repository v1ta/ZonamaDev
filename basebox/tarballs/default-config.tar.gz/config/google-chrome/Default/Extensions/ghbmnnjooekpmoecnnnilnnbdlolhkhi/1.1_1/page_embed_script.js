(function() { window._docs_chrome_extension_exists=!0;window._docs_chrome_extension_permissions=["alarms","clipboardRead","clipboardWrite","storage","unlimitedStorage"]; })()
